from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework import status
from core.models import UserProfile, Product
from core.serializers import UserProfileSerializer, ProductSerializer


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def admin_get_all_users(request):
    if not request.userprofile.is_admin:
        return Response({'detail': 'Unauthorized'}, status=403)

    users = UserProfile.objects.all()
    return Response(UserProfileSerializer(users, many=True).data)

@api_view(['PATCH'])
@permission_classes([IsAuthenticated])
def admin_update_user(request, uid):
    if not request.userprofile.is_admin:
        return Response({'detail': 'Unauthorized'}, status=403)

    user = UserProfile.objects.get(uid=uid)
    user.is_admin = request.data.get('is_admin', user.is_admin)
    user.rcoins = request.data.get('rcoins', user.rcoins)
    user.save()
    return Response(UserProfileSerializer(user).data)

@api_view(['GET'])
@permission_classes([IsAuthenticated])
def admin_get_all_products(request):
    if not request.userprofile.is_admin:
        return Response({'detail': 'Unauthorized'}, status=403)

    products = Product.objects.all().order_by('-created_at')
    return Response(ProductSerializer(products, many=True).data)


@api_view(['POST'])
@permission_classes([IsAuthenticated])
def admin_create_product(request):
    if not request.userprofile.is_admin:
        return Response({'detail': 'Unauthorized'}, status=403)

    serializer = ProductSerializer(data=request.data)
    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data, status=status.HTTP_201_CREATED)
    return Response(serializer.errors, status=400)


@api_view(['PUT', 'PATCH'])
@permission_classes([IsAuthenticated])
def admin_update_product(request, product_id):
    if not request.userprofile.is_admin:
        return Response({'detail': 'Unauthorized'}, status=403)

    product = Product.objects.get(pk=product_id)
    serializer = ProductSerializer(product, data=request.data, partial=True)
    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data)
    return Response(serializer.errors, status=400)


@api_view(['DELETE'])
@permission_classes([IsAuthenticated])
def admin_delete_product(request, product_id):
    if not request.userprofile.is_admin:
        return Response({'detail': 'Unauthorized'}, status=403)

    product = Product.objects.get(pk=product_id)
    product.delete()
    return Response(status=204)