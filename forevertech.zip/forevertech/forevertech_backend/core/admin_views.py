from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework import status
from core.models import UserProfile, Product, RCoinsOffer, Order, OrderItem
from core.serializers import UserProfileSerializer, ProductSerializer, RCoinsOfferSerializer, OrderSerializer


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def admin_get_all_users(request):
    if not hasattr(request.user, 'is_admin') or not request.user.is_admin:
        return Response({'detail': 'Unauthorized'}, status=403)

    users = UserProfile.objects.all()
    return Response(UserProfileSerializer(users, many=True).data)

@api_view(['PATCH'])
@permission_classes([IsAuthenticated])
def admin_update_user(request, uid):
    if not hasattr(request.user, 'is_admin') or not request.user.is_admin:
        return Response({'detail': 'Unauthorized'}, status=403)

    user = UserProfile.objects.get(uid=uid)
    user.is_admin = request.data.get('is_admin', user.is_admin)
    user.rcoins = request.data.get('rcoins', user.rcoins)
    user.save()
    return Response(UserProfileSerializer(user).data)


@api_view(['DELETE'])
@permission_classes([IsAuthenticated])
def admin_delete_user(request, uid):
    if not hasattr(request.user, 'is_admin') or not request.user.is_admin:
        return Response({'detail': 'Unauthorized'}, status=403)

    try:
        user = UserProfile.objects.get(uid=uid)
        user.delete()
        return Response(status=204)
    except UserProfile.DoesNotExist:
        return Response({'detail': 'User not found'}, status=404)


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def admin_get_all_products(request):
    if not hasattr(request.user, 'is_admin') or not request.user.is_admin:
        return Response({'detail': 'Unauthorized'}, status=403)

    products = Product.objects.all().order_by('-created_at')
    return Response(ProductSerializer(products, many=True).data)


@api_view(['POST'])
@permission_classes([IsAuthenticated])
def admin_create_product(request):
    if not hasattr(request.user, 'is_admin') or not request.user.is_admin:
        return Response({'detail': 'Unauthorized'}, status=403)

    serializer = ProductSerializer(data=request.data)
    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data, status=status.HTTP_201_CREATED)
    return Response(serializer.errors, status=400)


@api_view(['PUT', 'PATCH'])
@permission_classes([IsAuthenticated])
def admin_update_product(request, product_id):
    if not hasattr(request.user, 'is_admin') or not request.user.is_admin:
        return Response({'detail': 'Unauthorized'}, status=403)

    product = Product.objects.get(pk=product_id)
    serializer = ProductSerializer(product, data=request.data, partial=True)
    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data)
    return Response(serializer.errors, status=400)


@api_view(['DELETE'])
@permission_classes([IsAuthenticated])
def admin_delete_product(request, product_id):
    if not hasattr(request.user, 'is_admin') or not request.user.is_admin:
        return Response({'detail': 'Unauthorized'}, status=403)

    product = Product.objects.get(pk=product_id)
    product.delete()
    return Response(status=204)


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def admin_list_rcoins_offers(request):
    if not hasattr(request.user, 'is_admin') or not request.user.is_admin:
        return Response({'detail': 'Unauthorized'}, status=403)
    offers = RCoinsOffer.objects.all().order_by('id')
    return Response(RCoinsOfferSerializer(offers, many=True).data)

@api_view(['POST'])
@permission_classes([IsAuthenticated])
def admin_create_rcoins_offer(request):
    if not hasattr(request.user, 'is_admin') or not request.user.is_admin:
        return Response({'detail': 'Unauthorized'}, status=403)
    serializer = RCoinsOfferSerializer(data=request.data)
    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data, status=201)
    return Response(serializer.errors, status=400)

@api_view(['PATCH'])
@permission_classes([IsAuthenticated])
def admin_update_rcoins_offer(request, offer_id):
    if not hasattr(request.user, 'is_admin') or not request.user.is_admin:
        return Response({'detail': 'Unauthorized'}, status=403)
    try:
        offer = RCoinsOffer.objects.get(pk=offer_id)
    except RCoinsOffer.DoesNotExist:
        return Response({'detail': 'Offer not found'}, status=404)
    serializer = RCoinsOfferSerializer(offer, data=request.data, partial=True)
    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data)
    return Response(serializer.errors, status=400)

@api_view(['DELETE'])
@permission_classes([IsAuthenticated])
def admin_delete_rcoins_offer(request, offer_id):
    if not hasattr(request.user, 'is_admin') or not request.user.is_admin:
        return Response({'detail': 'Unauthorized'}, status=403)
    try:
        offer = RCoinsOffer.objects.get(pk=offer_id)
        offer.delete()
        return Response(status=204)
    except RCoinsOffer.DoesNotExist:
        return Response({'detail': 'Offer not found'}, status=404)


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def admin_list_all_orders(request):
    if not getattr(request.user, 'is_admin', False):
        return Response({'detail': 'Unauthorized'}, status=403)

    orders = Order.objects.all().order_by('-created_at')
    serialized = OrderSerializer(orders, many=True)
    return Response(serialized.data)


@api_view(['POST'])
@permission_classes([IsAuthenticated])
def admin_revoke_order(request, order_id):
    if not getattr(request.user, 'is_admin', False):
        return Response({'detail': 'Unauthorized'}, status=403)

    try:
        order = Order.objects.get(id=order_id)
    except Order.DoesNotExist:
        return Response({'detail': 'Order not found'}, status=404)

    user = order.user

    # Devolver los rcoins al usuario
    user.rcoins += order.total_rcoins
    user.save()

    # Devolver stock
    for item in order.items.all():
        product = item.product
        product.stock += item.quantity
        product.save()

    # Eliminar el pedido
    order.delete()

    return Response({'detail': 'Order revoked and r-coins refunded.'})