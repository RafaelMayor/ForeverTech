from django.db import models

class UserProfile(models.Model):
    uid = models.CharField(max_length=128, unique=True)  # Firebase UID
    email = models.EmailField(unique=True)
    is_admin = models.BooleanField(default=False)
    rcoins = models.IntegerField(default=3000)

    def __str__(self):
        return self.email

class Product(models.Model):
    name = models.CharField(max_length=255)
    description = models.TextField()
    category = models.CharField(max_length=100)
    price_rcoins = models.PositiveIntegerField()
    stock = models.PositiveIntegerField(default=0)
    image_url = models.URLField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name

class Order(models.Model):
    user = models.ForeignKey(UserProfile, on_delete=models.CASCADE)
    total_rcoins = models.PositiveIntegerField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Order #{self.id} by {self.user.email}"


class OrderItem(models.Model):
    order = models.ForeignKey(Order, related_name='items', on_delete=models.CASCADE)
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField()
    price_at_purchase = models.PositiveIntegerField()  # en r-coins

    def __str__(self):
        return f"{self.quantity} x {self.product.name}"

class RCoinsOffer(models.Model):
    rcoins = models.PositiveIntegerField()
    price_eur = models.DecimalField(max_digits=6, decimal_places=2)

    def __str__(self):
        return f"{self.rcoins} R-Coins for {self.price_eur}€"
