from rest_framework import serializers
from .models import UserProfile, Product, Order, OrderItem, RCoinsOffer
from core.tasks import send_order_confirmation_email

class UserProfileSerializer(serializers.ModelSerializer):
    class Meta:
        model = UserProfile
        fields = ['uid', 'email', 'is_admin', 'rcoins']


class ProductSerializer(serializers.ModelSerializer):
    class Meta:
        model = Product
        fields = '__all__'


class OrderItemSerializer(serializers.ModelSerializer):
    product = serializers.PrimaryKeyRelatedField(queryset=Product.objects.all())
    product_name = serializers.CharField(source='product.name', read_only=True)

    class Meta:
        model = OrderItem
        fields = ['product', 'product_name', 'quantity', 'price_at_purchase']
        read_only_fields = ['price_at_purchase']


class OrderSerializer(serializers.ModelSerializer):
    items = OrderItemSerializer(many=True)
    user = UserProfileSerializer(read_only=True)

    class Meta:
        model = Order
        fields = ['id', 'user', 'total_rcoins', 'created_at', 'items']
        read_only_fields = ['user', 'total_rcoins', 'created_at']

    def create(self, validated_data):
        items_data = validated_data.pop('items')
        user = self.context['request'].user

        total_cost = 0
        order_items = []

        for item in items_data:
            product = item['product']
            quantity = item['quantity']

            if product.stock < quantity:
                raise serializers.ValidationError(f"Not enough stock for {product.name}")

            cost = product.price_rcoins * quantity
            total_cost += cost
            order_items.append((product, quantity, cost))

        if user.rcoins < total_cost:
            raise serializers.ValidationError("Not enough r-coins")

        user.rcoins -= total_cost
        user.save()

        for product, quantity, _ in order_items:
            product.stock -= quantity
            product.save()

        order = Order.objects.create(user=user, total_rcoins=total_cost)
        for product, quantity, cost in order_items:
            OrderItem.objects.create(order=order, product=product, quantity=quantity, price_at_purchase=product.price_rcoins)

        send_order_confirmation_email.delay(order.id)

        return order




class RCoinsOfferSerializer(serializers.ModelSerializer):
    class Meta:
        model = RCoinsOffer
        fields = ['id', 'rcoins', 'price_eur']
