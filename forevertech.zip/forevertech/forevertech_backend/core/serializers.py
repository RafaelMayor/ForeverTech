from rest_framework import serializers
from .models import UserProfile, Product, Order, OrderItem, RCoinsOffer

class UserProfileSerializer(serializers.ModelSerializer):
    class Meta:
        model = UserProfile
        fields = ['uid', 'email', 'is_admin', 'rcoins']


class ProductSerializer(serializers.ModelSerializer):
    class Meta:
        model = Product
        fields = '__all__'


class OrderItemSerializer(serializers.ModelSerializer):
    product = serializers.PrimaryKeyRelatedField(queryset=Product.objects.all())

    class Meta:
        model = OrderItem
        fields = ['product', 'quantity', 'price_at_purchase']
        read_only_fields = ['price_at_purchase']


class OrderSerializer(serializers.ModelSerializer):
    items = OrderItemSerializer(many=True)

    class Meta:
        model = Order
        fields = ['id', 'user', 'total_rcoins', 'created_at', 'items']
        read_only_fields = ['user', 'total_rcoins', 'created_at', 'price_at_purchase']

    def create(self, validated_data):
        items_data = validated_data.pop('items')
        request = self.context['request']
        auth_header = request.headers.get('Authorization', '')
        id_token = auth_header.replace('Bearer ', '')

        from .firebase import verify_firebase_token
        decoded = verify_firebase_token(id_token)
        if not decoded:
            raise serializers.ValidationError("Invalid token")

        uid = decoded['uid']
        user = UserProfile.objects.get(uid=uid)

        total_cost = 0
        order_items = []

        for item in items_data:
            product = Product.objects.get(id=item['product'].id if hasattr(item['product'], 'id') else item['product'])
            quantity = item['quantity']

            if product.stock < quantity:
                raise serializers.ValidationError(f"Not enough stock for {product.name}")

            cost = product.price_rcoins * quantity
            total_cost += cost
            order_items.append((product, quantity, cost))

        if user.rcoins < total_cost:
            raise serializers.ValidationError("Not enough r-coins")

        # Deduct coins and update stock
        user.rcoins -= total_cost
        user.save()

        for product, quantity, _ in order_items:
            product.stock -= quantity
            product.save()

        # Create order
        order = Order.objects.create(user=user, total_rcoins=total_cost)
        for product, quantity, cost in order_items:
            OrderItem.objects.create(order=order, product=product, quantity=quantity, price_at_purchase=product.price_rcoins)

        return order


class RCoinsOfferSerializer(serializers.ModelSerializer):
    class Meta:
        model = RCoinsOffer
        fields = ['id', 'rcoins', 'price_eur']
