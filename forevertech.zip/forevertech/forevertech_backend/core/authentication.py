from rest_framework.authentication import BaseAuthentication
from rest_framework.exceptions import AuthenticationFailed
from .firebase import verify_firebase_token
from .models import UserProfile

class FirebaseAuthentication(BaseAuthentication):
    def authenticate(self, request):
        auth_header = request.headers.get('Authorization')
        if not auth_header:
            return None

        id_token = auth_header.replace('Bearer ', '')
        decoded_token = verify_firebase_token(id_token)

        if not decoded_token:
            raise AuthenticationFailed('Invalid Firebase token')

        uid = decoded_token.get('uid')
        try:
            user_profile = UserProfile.objects.get(uid=uid)
        except UserProfile.DoesNotExist:
            raise AuthenticationFailed('User not found')

        return (user_profile, None)

