from django.urls import path, include
from .views import FirebaseAuthView, ProductViewSet, OrderListCreateView, RCoinsOfferListView, PurchaseRCoinsView, RCoinsOfferViewSet
from rest_framework.routers import DefaultRouter
from . import admin_views

router = DefaultRouter()
router.register(r'products', ProductViewSet, basename='product')

urlpatterns = [
    path('auth/', FirebaseAuthView.as_view(), name='firebase-auth'),
    path('', include(router.urls)),
    path('orders/', OrderListCreateView.as_view(), name='orders'),
    path('admin/users/', admin_views.admin_get_all_users),
    path('admin/users/<str:uid>/', admin_views.admin_update_user),
    path('admin/products/', admin_views.admin_get_all_products),
    path('admin/products/create/', admin_views.admin_create_product),
    path('admin/products/<int:product_id>/', admin_views.admin_update_product),
    path('admin/products/<int:product_id>/delete/', admin_views.admin_delete_product),
    path('rcoins-offers/', RCoinsOfferListView.as_view(), name='rcoins-offers'),
    path('purchase-rcoins/', PurchaseRCoinsView.as_view(), name='purchase-rcoins'),
]

admin_router = DefaultRouter()
admin_router.register(r'admin/rcoins-offers', RCoinsOfferViewSet, basename='rcoins-offer')

urlpatterns += admin_router.urls
