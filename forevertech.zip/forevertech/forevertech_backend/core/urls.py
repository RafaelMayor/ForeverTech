from django.urls import path, include
from .views import FirebaseAuthView, ProductViewSet, OrderListCreateView, RCoinsOfferListView, PurchaseRCoinsView
from rest_framework.routers import DefaultRouter
from . import admin_views

router = DefaultRouter()
router.register(r'products', ProductViewSet, basename='product')

urlpatterns = [
    path('auth/', FirebaseAuthView.as_view(), name='firebase-auth'),
    path('', include(router.urls)),
    path('orders/', OrderListCreateView.as_view(), name='orders'),
    path('admin/users/', admin_views.admin_get_all_users),
    path('admin/users/<str:uid>/', admin_views.admin_update_user),
    path('admin/users/<str:uid>/delete/', admin_views.admin_delete_user),
    path('admin/products/', admin_views.admin_get_all_products),
    path('admin/products/create/', admin_views.admin_create_product),
    path('admin/products/<int:product_id>/', admin_views.admin_update_product),
    path('admin/products/<int:product_id>/delete/', admin_views.admin_delete_product),
    path('admin/rcoins-offers/', admin_views.admin_list_rcoins_offers),
    path('admin/rcoins-offers/create/', admin_views.admin_create_rcoins_offer),
    path('admin/rcoins-offers/<int:offer_id>/', admin_views.admin_update_rcoins_offer),
    path('admin/rcoins-offers/<int:offer_id>/delete/', admin_views.admin_delete_rcoins_offer),
    path('admin/orders/', admin_views.admin_list_all_orders),
    path('admin/orders/<int:order_id>/revoke/', admin_views.admin_revoke_order),
    path('rcoins-offers/', RCoinsOfferListView.as_view(), name='rcoins-offers'),
    path('purchase-rcoins/', PurchaseRCoinsView.as_view(), name='purchase-rcoins'),
]
