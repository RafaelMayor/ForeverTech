from celery import shared_task
from django.core.mail import send_mail
from .models import Order

@shared_task
def send_order_confirmation_email(order_id):
    try:
        order = Order.objects.get(id=order_id)
        subject = f"Confirmación de compra #{order.id}"
        message = (
            f"Gracias por tu compra en ForeverTech, {order.user.email}.\n\n"
            f"Has gastado {order.total_rcoins} R-Coins.\n\n"
            f"Detalles de tu pedido:\n"
        )

        for item in order.items.all():
            message += f"- {item.quantity} x {item.product.name} @ {item.price_at_purchase} R-Coins\n"

        message += "\n¡Gracias por confiar en nosotros!"

        send_mail(
            subject,
            message,
            'no-reply@forevertech.com',
            [order.user.email],
            fail_silently=False
        )
    except Exception as e:
        print(f"❌ Error al enviar email de orden #{order_id}: {str(e)}")
