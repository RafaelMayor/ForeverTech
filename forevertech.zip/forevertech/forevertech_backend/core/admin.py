from django.contrib import admin
from .models import UserProfile, Product, RCoinsOffer

admin.site.register(UserProfile)
admin.site.register(Product)
admin.site.register(RCoinsOffer)
