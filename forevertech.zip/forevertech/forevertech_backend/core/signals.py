from django.db.models.signals import post_save, post_delete
from django.dispatch import receiver
from .models import UserProfile
from firebase_admin import firestore


@receiver(post_save, sender=UserProfile)
def sync_user_to_firestore(sender, instance, **kwargs):
    db = firestore.client()
    db.collection('users').document(instance.uid).set({
        'uid': instance.uid,
        'email': instance.email,
        'is_admin': instance.is_admin,
        'rcoins': instance.rcoins,
    })


@receiver(post_delete, sender=UserProfile)
def delete_user_from_firestore(sender, instance, **kwargs):
    db = firestore.client()
    db.collection('users').document(instance.uid).delete()
