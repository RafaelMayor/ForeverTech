from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status, viewsets, generics
from .models import UserProfile, Product, Order, RCoinsOffer
from .serializers import UserProfileSerializer, ProductSerializer, OrderSerializer, RCoinsOfferSerializer
from .firebase import verify_firebase_token
from .permissions import IsAdminUserFirebase
from .utils import get_user_from_request
from firebase_admin import firestore
from rest_framework.permissions import AllowAny, IsAuthenticatedOrReadOnly, IsAuthenticated


class FirebaseAuthView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        id_token = request.data.get('idToken')
        if not id_token:
            return Response({'error': 'ID token missing'}, status=status.HTTP_400_BAD_REQUEST)

        decoded_token = verify_firebase_token(id_token)
        if not decoded_token:
            return Response({'error': 'Invalid Firebase token'}, status=status.HTTP_401_UNAUTHORIZED)

        uid = decoded_token['uid']
        email = decoded_token.get('email', '')

        user, created = UserProfile.objects.get_or_create(uid=uid, defaults={'email': email})

        # Si el usuario fue recién creado en Django, lo sincronizamos en Firestore
        if created:
            db = firestore.client()
            db.collection('users').document(uid).set({
                'uid': uid,
                'email': email,
                'is_admin': False,
                'rcoins': 3000,
            })

        serializer = UserProfileSerializer(user)
        return Response(serializer.data, status=status.HTTP_200_OK)

class ProductViewSet(viewsets.ModelViewSet):
    queryset = Product.objects.all()
    serializer_class = ProductSerializer

    def get_permissions(self):
        if self.action in ['create', 'update', 'partial_update', 'destroy']:
            return [IsAdminUserFirebase()]
        return [AllowAny()]

class OrderListCreateView(generics.ListCreateAPIView):
    serializer_class = OrderSerializer
    permission_classes = [IsAuthenticatedOrReadOnly]

    def get_queryset(self):
        try:
            user = get_user_from_request(self.request)
            return Order.objects.filter(user=user).order_by('-created_at')
        except:
            return Order.objects.none()

    def create(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data, context={'request': request})
            serializer.is_valid(raise_exception=True)
            order = serializer.save()
            return Response(OrderSerializer(order).data, status=status.HTTP_201_CREATED)
        except Exception as e:
            import traceback
            print("🔥 Error al crear orden:")
            traceback.print_exc()
            return Response({'error': str(e)}, status=500)



class RCoinsOfferListView(generics.ListAPIView):
    queryset = RCoinsOffer.objects.all()
    serializer_class = RCoinsOfferSerializer


class PurchaseRCoinsView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        offer_id = request.data.get('offer_id')
        if not offer_id:
            return Response({'error': 'Missing offer_id'}, status=400)

        try:
            offer = RCoinsOffer.objects.get(id=offer_id)
        except RCoinsOffer.DoesNotExist:
            return Response({'error': 'Offer not found'}, status=404)

        try:
            user = get_user_from_request(request)
        except AuthenticationFailed as e:
            return Response({'error': str(e)}, status=401)

        user.rcoins += offer.rcoins
        user.save()

        return Response(UserProfileSerializer(user).data, status=200)



class RCoinsOfferViewSet(viewsets.ModelViewSet):
    queryset = RCoinsOffer.objects.all()
    serializer_class = RCoinsOfferSerializer
    permission_classes = [IsAdminUserFirebase]

    def get_queryset(self):
        return RCoinsOffer.objects.all()