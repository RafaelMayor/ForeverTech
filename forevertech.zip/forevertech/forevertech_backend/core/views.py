from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status, viewsets, generics
from .models import UserProfile, Product, Order, RCoinsOffer
from .serializers import UserProfileSerializer, ProductSerializer, OrderSerializer, RCoinsOfferSerializer
from .firebase import verify_firebase_token
from .permissions import IsAdminUserFirebase
from rest_framework.permissions import AllowAny, IsAuthenticatedOrReadOnly, IsAuthenticated


class FirebaseAuthView(APIView):
    def post(self, request):
        id_token = request.data.get('idToken')
        if not id_token:
            return Response({'error': 'ID token missing'}, status=status.HTTP_400_BAD_REQUEST)

        decoded_token = verify_firebase_token(id_token)
        if not decoded_token:
            return Response({'error': 'Invalid Firebase token'}, status=status.HTTP_401_UNAUTHORIZED)

        uid = decoded_token['uid']
        email = decoded_token.get('email', '')

        user, created = UserProfile.objects.get_or_create(uid=uid, defaults={'email': email})

        # Si el usuario fue recién creado en Django, lo sincronizamos en Firestore
        if created:
            db = firestore.client()
            db.collection('users').document(uid).set({
                'uid': uid,
                'email': email,
                'is_admin': False,
                'rcoins': 3000,
            })

        serializer = UserProfileSerializer(user)
        return Response(serializer.data, status=status.HTTP_200_OK)

class ProductViewSet(viewsets.ModelViewSet):
    queryset = Product.objects.all()
    serializer_class = ProductSerializer

    def get_permissions(self):
        if self.action in ['create', 'update', 'partial_update', 'destroy']:
            return [IsAdminUserFirebase()]
        return [AllowAny()]

class OrderListCreateView(generics.ListCreateAPIView):
    serializer_class = OrderSerializer
    permission_classes = [IsAuthenticatedOrReadOnly]

    def get_queryset(self):
        auth_header = self.request.headers.get('Authorization', '')
        id_token = auth_header.replace('Bearer ', '')
        decoded = verify_firebase_token(id_token)
        if not decoded:
            return Order.objects.none()

        uid = decoded['uid']
        return Order.objects.filter(user__uid=uid).order_by('-created_at')

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data, context={'request': request})
        serializer.is_valid(raise_exception=True)
        order = serializer.save()
        return Response(OrderSerializer(order).data, status=status.HTTP_201_CREATED)


class RCoinsOfferListView(generics.ListAPIView):
    queryset = RCoinsOffer.objects.all()
    serializer_class = RCoinsOfferSerializer


class PurchaseRCoinsView(APIView):
    permission_classes = [AllowAny]  # o simplemente elimina esta línea

    def post(self, request):
        offer_id = request.data.get('offer_id')
        if not offer_id:
            return Response({'error': 'Missing offer_id'}, status=400)

        try:
            offer = RCoinsOffer.objects.get(id=offer_id)
        except RCoinsOffer.DoesNotExist:
            return Response({'error': 'Offer not found'}, status=404)

        auth_header = request.headers.get('Authorization')
        if not auth_header or not auth_header.startswith('Bearer '):
            return Response({'error': 'Invalid Authorization header'}, status=403)

        id_token = auth_header.split(' ')[1]
        decoded = verify_firebase_token(id_token)
        if not decoded:
            return Response({'error': 'Invalid token'}, status=401)

        user = UserProfile.objects.get(uid=decoded['uid'])

        # Simulated payment always succeeds
        user.rcoins += offer.rcoins
        user.save()

        return Response(UserProfileSerializer(user).data, status=200)


class RCoinsOfferViewSet(viewsets.ModelViewSet):
    queryset = RCoinsOffer.objects.all()
    serializer_class = RCoinsOfferSerializer
    permission_classes = [IsAdminUserFirebase]