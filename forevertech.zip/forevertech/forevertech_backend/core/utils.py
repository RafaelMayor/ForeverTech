from .firebase import verify_firebase_token
from .models import UserProfile
from rest_framework.exceptions import AuthenticationFailed

def get_user_from_request(request):
    auth_header = request.headers.get('Authorization', '')
    if not auth_header.startswith('Bearer '):
        raise AuthenticationFailed("Invalid or missing Authorization header")
    
    id_token = auth_header.split(' ')[1]
    decoded = verify_firebase_token(id_token)
    if not decoded:
        raise AuthenticationFailed("Invalid Firebase token")
    
    try:
        return UserProfile.objects.get(uid=decoded['uid'])
    except UserProfile.DoesNotExist:
        raise AuthenticationFailed("User not found in system")
