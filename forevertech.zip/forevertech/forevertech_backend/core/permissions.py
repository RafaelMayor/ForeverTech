from rest_framework.permissions import BasePermission
from .models import UserProfile

class IsAdminUserFirebase(BasePermission):
    def has_permission(self, request, view):
        id_token = request.headers.get('Authorization')
        if not id_token:
            return False

        from .firebase import verify_firebase_token
        decoded = verify_firebase_token(id_token)

        if not decoded:
            return False

        uid = decoded['uid']
        try:
            user = UserProfile.objects.get(uid=uid)
            return user.is_admin
        except UserProfile.DoesNotExist:
            return False
