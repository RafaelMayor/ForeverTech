# populate_firestore_users.py

import firebase_admin
from firebase_admin import credentials, firestore
from django.conf import settings
from core.models import UserProfile  # Ajusta el import a tu modelo real

def populate_users_in_firestore():
    # Solo inicializar si no se ha hecho ya
    if not firebase_admin._apps:
        cred = credentials.Certificate(settings.FIREBASE_CREDENTIALS)
        firebase_admin.initialize_app(cred)

    db = firestore.client()

    users = UserProfile.objects.all()
    for user in users:
        user_data = {
            'uid': user.uid,
            'email': user.email,
            'is_admin': user.is_admin,
            'rcoins': user.rcoins,
        }

        doc_ref = db.collection('users').document(user.uid)
        doc_ref.set(user_data)

        print(f'Usuario {user.email} (uid={user.uid}) agregado/actualizado en Firestore.')

if __name__ == '__main__':
    populate_users_in_firestore()
