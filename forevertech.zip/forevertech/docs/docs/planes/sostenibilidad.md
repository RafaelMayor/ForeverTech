## ✅ PLAN DE SOSTENIBILIDAD

### **2.1 Sostenibilidad económica**

* **Modelo rentable y diversificado**:

  * Ingresos por ventas directas y por packs promocionales.
  * Posibilidad de servicios adicionales a largo plazo (formación, soporte, kits de reparación).

* **Control de costes**:

  * Inventario ajustado a demanda gracias a análisis de comportamiento de compra.
  * Plataforma desarrollada internamente, evitando fees de terceros.

* **Uso de R-Coins**:

  * Fomenta la fidelización y reduce costes en adquisición de nuevos clientes.

---

### **2.2 Sostenibilidad social**

* **Accesibilidad**:

  * Plataforma totalmente responsive y con diseño accesible (colores contrastados, navegación por teclado, textos alternativos).
  * Política de precios justos y posibilidad de pago con saldo virtual acumulado (R-Coins).

* **Ética**:

  * Productos seleccionados con criterios éticos (fabricantes comprometidos con la transparencia).
  * Rechazo a modelos de consumo rápido o de baja calidad.

* **Acciones para la comunidad**:

  * Programa de formación gratuita online: “Repara tu tecnología”.
  * Colaboración con colectivos que luchan contra la brecha digital (donaciones de excedente a asociaciones).

---

### **2.3 Sostenibilidad ambiental**

* **Hosting verde**:

  * La web estará alojada en un proveedor que utiliza energías 100% renovables (como GreenGeeks o Infomaniak).

* **Diseño optimizado**:

  * Carga eficiente, imágenes comprimidas, lazy loading y frontend desacoplado (Vue 3).
  * Menor consumo de datos = menor huella de carbono digital.

* **Digitalización de procesos**:

  * Gestión 100% digital de pedidos, facturación y soporte.
  * Evitamos documentación en papel, albaranes físicos o tickets impresos.
  * Preferencia por productos que incluyen manuales digitales y empaque reciclado.