## ✅ PLAN DE MARKETING

### **1.1 Análisis de mercado**

* **Cliente ideal (buyer persona)**:
  Adultos de 25 a 45 años con conciencia ambiental y tecnológica. Valoran la durabilidad, la ética de producción y el soporte a largo plazo. Profesionales del sector IT, estudiantes de ingeniería, diseñadores, y consumidores exigentes que rechazan la obsolescencia programada.

* **Competencia**:
  Competimos con grandes marketplaces como Amazon o PcComponentes, aunque nos diferenciamos claramente en valores (durabilidad, sostenibilidad). También con pequeñas tiendas especializadas que priorizan soporte técnico, pero sin nuestra propuesta de valor sostenible.

* **Tendencias del mercado**:
  Aumento del interés por productos éticos y sostenibles. Los consumidores cada vez investigan más antes de comprar. Crece la demanda de productos reparables, con soporte postventa prolongado y garantías extendidas. Las políticas europeas están favoreciendo el derecho a la reparación.

---

### **1.2 Propuesta de valor**

ForeverTech ofrece **productos electrónicos sin obsolescencia programada**, seleccionados por su **durabilidad, reparabilidad y soporte técnico real a largo plazo**.
Además, nuestro sistema de compra con **R-Coins** premia la fidelidad, facilita promociones personalizadas y fomenta el ahorro en próximas compras.

> 🔸 *"ForeverTech: Tecnología que no caduca."*

---

### **1.3 Estrategias de promoción y publicidad**

* **Marketing digital**:

  * SEO: Contenido optimizado en blog sobre sostenibilidad tecnológica, comparativas de productos duraderos.
  * SEM: Campañas en Google Ads y redes sociales con palabras clave como “productos sin obsolescencia programada”.

* **Contenidos y redes sociales**:

  * Instagram y TikTok: Reels de “productos que duran 10 años”, desmontajes de hardware reparable, consejos para alargar la vida útil de gadgets.
  * YouTube: Mini-documentales y comparativas sobre el impacto ambiental de la tecnología desechable.
  * Blog técnico y de opinión en la web.

* **Alianzas**:

  * Colaboración con ONGs tecnológicas y asociaciones de consumidores.
  * Afiliación con influencers y youtubers tech responsables.

---

### **1.4 Estrategia de ventas y precios**

* **Modelo de precios**:

  * Precios competitivos, ajustados al valor a largo plazo del producto (TCO: coste total de propiedad).
  * Sistema de recompensas con R-Coins por cada compra.
  * Descuentos escalonados por fidelidad o volumen.

* **Técnicas de venta**:

  * **Cross-selling**: Sugerencias de accesorios duraderos compatibles al añadir un producto al carrito.
  * **Upselling**: Recomendaciones de versiones más potentes con garantía extendida sin obsolescencia.
  * **Bundles sostenibles**: Packs de productos duraderos con instalación o formación técnica.

---

## **1.5 Medición y KPIs (Indicadores clave de rendimiento)**

Para que la estrategia de marketing sea realmente efectiva, necesitamos evaluar de forma **continua y objetiva** su impacto. Para ello, definimos una serie de KPIs (Key Performance Indicators) que nos permitirán tomar decisiones basadas en datos reales, detectar errores a tiempo y optimizar nuestras campañas y procesos de venta.

### **Conversión**

* **Definición**: Porcentaje de visitantes que realizan una compra en la tienda online.
* **Cálculo**:

  Tasa de conversión = Nº de pedidos / Nº de visitas x 100

* **Objetivo inicial**: 2% (es decir, que de cada 100 personas que visitan la tienda, al menos 2 compren algo).
* **Uso**: Permite medir la eficacia del sitio web, la confianza que genera y la calidad del tráfico que atraemos. Si es baja, revisamos el proceso de compra, la experiencia de usuario o las campañas de adquisición.

---

### **Retención de clientes**

* **Definición**: Porcentaje de clientes que vuelven a comprar en un periodo determinado.
* **Objetivo a 6 meses**: 25% (1 de cada 4 clientes vuelve a comprar).
* **Importancia**: Un cliente que vuelve es más rentable a largo plazo. La retención también indica satisfacción con el producto y la experiencia postventa.
* **Medición**: Seguimiento de cuentas de usuario, historial de pedidos y uso de R-Coins.

---

### **Ticket medio (valor medio del pedido)**

* **Definición**: Promedio de gasto por pedido, medido en euros y en R-Coins.
* **Cálculo**:

  Ticket medio = Ingresos totales / Nº total de pedidos

* **Importancia**: Nos ayuda a diseñar estrategias de upselling y bundles más efectivos. Un ticket medio bajo puede indicar falta de interés en productos complementarios o poco incentivo en las promociones.

---

### **ROI de campañas de marketing**

* **Definición**: Retorno sobre la inversión en publicidad (Google Ads, redes sociales, influencers...).
* **Cálculo**:

  ROI = ((Ganancia generada por la campaña - Coste de la campaña) / Coste de la campaña) x 100

* **Ejemplo**: Si invertimos 200 € en una campaña y generamos 800 € en ventas atribuibles, el ROI es del 300%.
* **Uso**: Detectamos qué campañas funcionan mejor, qué canales son más rentables y dónde optimizar el presupuesto.

---

### **Engagement en redes sociales**

* **Definición**: Grado de interacción del público con nuestro contenido (likes, shares, comentarios, clics).
* **Métricas específicas**:

  * Tasa de interacción (por post y por red).
  * Crecimiento de seguidores.
  * Tiempo de visualización en vídeos.
* **Plataformas clave**: Instagram, TikTok, YouTube.
* **Uso**: El engagement indica la calidad del contenido y el interés real de la audiencia. A mayor interacción, más alcance orgánico y mayor fidelización de marca.

---

### **Satisfacción del cliente (NPS y encuestas post-compra)**

* **Net Promoter Score (NPS)**:

  * Pregunta directa: “¿Recomendarías ForeverTech a un amigo o familiar?”
  * Escala de 0 a 10.

    * Promotores (9–10), Pasivos (7–8), Detractores (0–6).
  * Cálculo:

    NPS = %Promotores − %Detractores

* **Encuestas adicionales**: Valoración del proceso de compra, envío, atención al cliente, calidad del producto.
* **Uso**: Estas métricas reflejan directamente la experiencia del cliente y permiten detectar problemas antes de que afecten la reputación o las ventas.

---

### **Otros indicadores adicionales**

* **Tasa de abandono del carrito**: Si muchos usuarios añaden productos pero no finalizan la compra, hay que revisar el proceso de pago o añadir incentivos.
* **Coste de adquisición por cliente (CAC)**: Cuánto invertimos en conseguir un nuevo cliente.
* **Tiempo medio en el sitio web**: Cuanto más tiempo pasen, más interés existe. Un descenso puede indicar problemas de navegación o velocidad de carga.

---

### 📊 Herramientas para el seguimiento

* **Google Analytics 4**: Para métricas de tráfico, conversión y comportamiento en la tienda.
* **Google Search Console**: Para SEO y rendimiento en búsquedas.
* **Meta Business Suite / TikTok Analytics / YouTube Studio**: Para redes sociales.
* **Plataformas de email marketing**: (como Mailchimp o Brevo) para medir tasas de apertura y clics en campañas.
* **Herramientas internas del backend**: para R-Coins, ticket medio, frecuencia de compra y retención.