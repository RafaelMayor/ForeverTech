# Introducción al Frontend

El frontend de ForeverTech ha sido desarrollado con **Vue 3**, empleando la **Composition API**, **TypeScript** y el formato **Single File Component (SFC)**. La arquitectura se organiza en componentes reutilizables, vistas bien definidas y una gestión del estado global mediante **Pinia**.

El enfoque del desarrollo prioriza la mantenibilidad, la escalabilidad y la experiencia del usuario, con un diseño responsive, accesible y adaptado tanto para usuarios como para administradores.

## Tecnologías utilizadas

- **Vue 3** (Composition API)
- **TypeScript**
- **Vue Router**
- **Pinia** (gestión de estado)
- **Firebase Auth** (autenticación)
- **Axios** (peticiones HTTP)
- **Bootstrap 5** (estilo base, adaptado)
- **Vitest** (test unitarios)

---

## Arquitectura

- `/views`: Vistas principales del sistema.
- `/components`: Componentes reutilizables.
- `/composables`: Lógica reutilizable (composables).
- `/stores`: Estado global (Pinia).
- `/router`: Definición de rutas y navegación.
- `/interfaces`: Interfaces TypeScript compartidas.
- `/tests`: Tests Unitarios del Frontend.

La estructura facilita la separación de responsabilidades, el testeo y la integración continua del sistema.

