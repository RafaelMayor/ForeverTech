# Vistas del Frontend

A continuación se documentan las vistas principales de la aplicación frontend de ForeverTech:

---

## `LoginView`

Pantalla de inicio de sesión para usuarios registrados. Utiliza Firebase Auth para validar las credenciales y obtener el `ID Token`, que se envía al backend para la autenticación.

- Validaciones en el cliente.
- Gestión de errores y mensajes.
- Redirección automática tras login exitoso.

---

## `SignupView`

Vista para registrar nuevos usuarios. Crea la cuenta en Firebase y sincroniza el perfil en el backend (UserProfile).

- Validación de contraseñas seguras.
- Alta automática en el backend vía API.
- Redirección automática tras signup exitoso.

---

## `HomeView`

Vista principal accesible para cualquier visitante autenticado o no.

- Presentación de la propuesta de valor.
- Acceso a productos destacados (carrusel de productos).
- Enlaces al catálogo completo.

---

## `ProductsView`

Muestra el catálogo completo de productos disponibles.

- Filtro por categoría.
- Animación al pasar el ratón por encima de los productos.
- Botón para añadir al carrito (según stock).

---

## `CartView`

Vista independiente del carrito de compras.

- Lista de productos añadidos.
- Posibilidad de editar cantidades o eliminar ítems.
- Visualización del total en R-Coins.
- Botón de "Finalizar compra".

---

## `OrdersView`

Historial personal de pedidos del usuario autenticado.

- Lista cronológica de pedidos.
- Detalles de cada pedido (productos, precios, fecha).

---

## `RCoinsPurchaseView`

Vista para comprar R-Coins mediante ofertas configuradas por el admin.

- Lista de paquetes disponibles.
- Simulación de pasarela de pago.
- Confirmación visual y recarga automática de saldo.

---

## `AdminUserManager`

Vista para admins donde pueden gestionar usuarios registrados.

- Lista de usuarios con búsqueda.
- Modificación de R-Coins.
- Cambios de rol (admin/usuario).

---

## `AdminProductManager`

CRUD completo de productos.

- Crear, editar o eliminar productos.
- Control de stock y precios.

---

## `AdminRCoinsOffers`

Gestión de ofertas de R-Coins.

- Crear nuevas ofertas (R-Coins y precio en €).
- Editar o eliminar ofertas existentes.
- Validación en tiempo real de campos numéricos.

---

## `AdminOrderHistory`

Vista de historial global de pedidos (solo para administradores).

- Visualización completa de pedidos de todos los usuarios.
- Opción de revocar pedidos y reembolsar R-Coins.

---

Cada vista está diseñada para maximizar la claridad, la usabilidad y la eficiencia tanto para usuarios finales como para el personal administrador.
