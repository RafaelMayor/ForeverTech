# Bienvenido a la documentación de ForeverTech

ForeverTech es una tienda online de tecnología sostenible que lucha contra la obsolescencia programada.
Aquí encontrarás toda la documentación técnica y estratégica del proyecto.
