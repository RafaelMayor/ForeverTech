# Modelos del Backend (`core/models.py`)

Este módulo define los modelos principales del backend de ForeverTech. Se utilizan para representar usuarios, productos, pedidos, ítems de pedido y ofertas de R-Coins.

---

## `UserProfile`

Representa un usuario autenticado mediante Firebase.

```python
class UserProfile(models.Model):
    uid = models.CharField(max_length=128, unique=True)  # Firebase UID
    email = models.EmailField(unique=True)
    is_admin = models.BooleanField(default=False)
    rcoins = models.IntegerField(default=3000)
```

* `uid`: ID único proporcionado por Firebase.
* `email`: Correo del usuario, usado como identificador.
* `is_admin`: Define si el usuario tiene privilegios de administración.
* `rcoins`: Moneda virtual del sistema, inicializada con 3000 por defecto.
* `is_authenticated` (propiedad): Siempre retorna `True` para usarse con autenticación personalizada.

---

## `Product`

Modelo para representar productos disponibles en la tienda.

```python
class Product(models.Model):
    name = models.CharField(max_length=255)
    description = models.TextField()
    category = models.CharField(max_length=100)
    price_rcoins = models.PositiveIntegerField()
    stock = models.PositiveIntegerField(default=0)
    image_url = models.URLField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
```

* `name`: Nombre del producto.
* `description`: Descripción detallada.
* `category`: Categoría del producto.
* `price_rcoins`: Precio en R-Coins.
* `stock`: Cantidad disponible.
* `image_url`: URL de la imagen del producto.
* `created_at`: Fecha de creación (automática).

---

## `Order`

Representa un pedido realizado por un usuario.

```python
class Order(models.Model):
    user = models.ForeignKey(UserProfile, on_delete=models.CASCADE)
    total_rcoins = models.PositiveIntegerField()
    created_at = models.DateTimeField(auto_now_add=True)
```

* `user`: Usuario que realizó el pedido.
* `total_rcoins`: Total en R-Coins del pedido.
* `created_at`: Fecha de creación.

---

## `OrderItem`

Ítems individuales que forman parte de un pedido.

```python
class OrderItem(models.Model):
    order = models.ForeignKey(Order, related_name='items', on_delete=models.CASCADE)
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField()
    price_at_purchase = models.PositiveIntegerField()
```

* `order`: Pedido al que pertenece el ítem.
* `product`: Producto comprado.
* `quantity`: Cantidad del producto.
* `price_at_purchase`: Precio del producto (en R-Coins) al momento de la compra.

---

## `RCoinsOffer`

Define ofertas para comprar paquetes de R-Coins con dinero real.

```python
class RCoinsOffer(models.Model):
    rcoins = models.PositiveIntegerField()
    price_eur = models.DecimalField(max_digits=6, decimal_places=2)
```

* `rcoins`: Cantidad de R-Coins ofrecidos.
* `price_eur`: Precio en euros del paquete.

---

Cada modelo ha sido diseñado para ser simple, funcional y fácilmente integrable con las vistas API del backend y el frontend desarrollado con Vue 3.
