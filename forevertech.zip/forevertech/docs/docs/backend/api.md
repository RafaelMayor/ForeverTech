# API

La API de ForeverTech está construida con Django REST Framework (DRF) y autenticación mediante Firebase.

---

## 🔐 Autenticación

Todas las rutas están protegidas por `FirebaseAuthentication`, que valida el token de usuario y sincroniza su información con el modelo `UserProfile`.

---

## 📘 Endpoints principales

### 🔹 `GET /api/products/`

Devuelve la lista de productos disponibles.

### 🔹 `POST /api/orders/`

Crea un nuevo pedido con los productos del carrito.

### 🔹 `GET /api/orders/`

Devuelve el historial de pedidos del usuario autenticado.

---

## 🎁 Ofertas de R-Coins

### 🔹 `GET /api/rcoins-offers/`

Lista todas las ofertas activas de compra de R-Coins.

### 🔹 `POST /api/purchase-rcoins/`

Inicia la compra de una oferta de R-Coins. Se integra con la pasarela de pago (simulada en entorno de desarrollo).

---

## ⚙️ Administración

### 🔹 `GET /admin/users/`

Devuelve la lista de usuarios, con opción de filtrar, editar R-Coins o cambiar rol.

### 🔹 `GET /admin/products/`, `POST`, `PUT`, `DELETE`

Gestión completa de productos.

### 🔹 `GET /admin/orders/`

Listado completo de pedidos con posibilidad de revocar.

### 🔹 `GET /admin/rcoins-offers/`, `POST`, `PUT`, `DELETE`

Gestión de ofertas de R-Coins desde el panel de administración.

---

## 🔁 Tareas asíncronas

El backend está preparado para procesar tareas desacopladas con Celery + Redis. Al comprar productos se le envía una notificación por correo electrónico al usuario.
