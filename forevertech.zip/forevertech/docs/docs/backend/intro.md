# Backend - Introducción

El backend de ForeverTech está desarrollado con **Django**, un framework robusto y escalable para aplicaciones web. Su estructura está diseñada para ser clara, segura y eficiente, integrándose perfectamente con el frontend basado en Vue 3.

El proyecto cuenta con una única app principal llamada `core`, donde se centraliza toda la lógica del servidor, incluyendo modelos, autenticación, administración y endpoints de la API REST.

Además, se ha configurado Celery para la gestión de tareas asíncronas, Redis como broker de mensajes y Firebase como sistema de autenticación externo.

---

## Tecnologías usadas

- Django
- Django REST Framework (DRF)
- Firebase Admin SDK
- Celery + Redis
