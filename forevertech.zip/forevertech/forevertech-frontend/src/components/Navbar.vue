<template>
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark px-3">
    <router-link class="navbar-brand" to="/">ForeverTech</router-link>

    <button
      class="navbar-toggler"
      type="button"
      data-bs-toggle="collapse"
      data-bs-target="#navbarNav"
    >
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav me-auto">
        <li class="nav-item">
          <router-link class="nav-link" to="/products">Products</router-link>
        </li>
        <li class="nav-item" v-if="user.uid">
          <router-link class="nav-link" to="/buy-rcoins">Buy R-Coins</router-link>
        </li>
        <li class="nav-item" v-if="user.uid">
          <router-link class="nav-link" to="/orders">Orders</router-link>
        </li>
        <li class="nav-item dropdown" v-if="user.isAdmin">
          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
            Admin
          </a>
          <ul class="dropdown-menu">
            <li>
              <router-link class="dropdown-item" to="/admin/products">Product Manager</router-link>
            </li>
            <li>
              <router-link class="dropdown-item" to="/admin/users">User Manager</router-link>
            </li>
            <li>
              <router-link class="dropdown-item" to="/admin/rcoins-offers">R-Coins Offers</router-link>
            </li>
            <li>
              <router-link class="dropdown-item" to="/admin/orders">Order History</router-link>
            </li>
          </ul>
        </li>
      </ul>

      <ul class="navbar-nav">
        <li class="nav-item" v-if="user.uid">
          <span class="nav-link text-success">💰 {{ user.rcoins }} R-Coins</span>
        </li>
        <li class="nav-item" v-if="user.uid">
          <router-link to="/cart" class="nav-link">Cart</router-link>
        </li>
        <li class="nav-item" v-if="user.uid">
          <a href="#" class="nav-link" @click.prevent="logout">Logout</a>
        </li>
        <li class="nav-item" v-if="!user.uid">
          <router-link class="nav-link" to="/login">Login</router-link>
        </li>
        <li class="nav-item" v-if="!user.uid">
          <router-link class="nav-link" to="/signup">Signup</router-link>
        </li>
      </ul>
    </div>
  </nav>
</template>

<script setup lang="ts">
import { useUserStore } from '../stores/user'
import { useRouter } from 'vue-router'
import { getAuth } from 'firebase/auth'

const user = useUserStore()
const router = useRouter()

const logout = async () => {
  await getAuth().signOut()
  user.clearUser()
  router.push('/login')
}
</script>
