<template>
  <div class="modal-backdrop show fade" style="z-index: 1050;"></div>
  <div class="modal show d-block" tabindex="-1">
    <div class="modal-dialog">
      <div class="modal-content">
        <form @submit.prevent="saveChanges">
          <div class="modal-header">
            <h5 class="modal-title">Edit User</h5>
            <button type="button" class="btn-close" @click="$emit('close')"></button>
          </div>
          <div class="modal-body">
            <div class="mb-3">
              <label class="form-label">Email</label>
              <input class="form-control" :value="user.email" disabled />
            </div>
            <div class="mb-3">
              <label class="form-label">Is Admin</label>
              <select class="form-select" v-model="isAdmin">
                <option :value="true">Yes</option>
                <option :value="false">No</option>
              </select>
            </div>
            <div class="mb-3">
              <label class="form-label">R-Coins</label>
              <input type="number" class="form-control" v-model.number="rcoins" />
            </div>
          </div>
          <div class="modal-footer">
            <button class="btn btn-success" type="submit">Save</button>
            <button class="btn btn-secondary" type="button" @click="$emit('close')">Cancel</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, watch } from 'vue'
import axios from 'axios'
import { useUserStore } from '../../stores/user'

const props = defineProps<{ user: any }>()
const emit = defineEmits(['close', 'saved'])
const userStore = useUserStore()

const isAdmin = ref(false)
const rcoins = ref(0)

watch(() => props.user, () => {
  isAdmin.value = props.user.is_admin
  rcoins.value = props.user.rcoins
}, { immediate: true })

const saveChanges = async () => {
  await axios.patch(`/api/admin/users/${props.user.uid}/`, {
    is_admin: isAdmin.value,
    rcoins: rcoins.value
  }, {
    headers: { Authorization: `Bearer ${userStore.token}` }
  })

  emit('saved')
  emit('close')
}
</script>
