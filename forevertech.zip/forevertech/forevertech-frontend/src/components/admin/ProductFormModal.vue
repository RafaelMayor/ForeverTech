<template>
  <div class="modal-backdrop show fade" style="z-index: 1050;"></div>
  <div class="modal show d-block" tabindex="-1">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <form @submit.prevent="submitForm">
          <div class="modal-header">
            <h5 class="modal-title">{{ product?.id ? 'Edit' : 'Create' }} Product</h5>
            <button type="button" class="btn-close" @click="$emit('close')"></button>
          </div>

          <div class="modal-body row g-3">
            <div class="col-md-6">
              <label class="form-label">Name</label>
              <input v-model="form.name" class="form-control" required />
            </div>
            <div class="col-md-6">
              <label class="form-label">Category</label>
              <input v-model="form.category" class="form-control" required />
            </div>
            <div class="col-12">
              <label class="form-label">Description</label>
              <textarea v-model="form.description" class="form-control" required></textarea>
            </div>
            <div class="col-md-4">
              <label class="form-label">Price (R-Coins)</label>
              <input v-model.number="form.price_rcoins" type="number" class="form-control" required />
            </div>
            <div class="col-md-4">
              <label class="form-label">Stock</label>
              <input v-model.number="form.stock" type="number" class="form-control" required />
            </div>
            <div class="col-md-4">
              <label class="form-label">Image URL</label>
              <input v-model="form.image_url" class="form-control" />
            </div>
          </div>

          <div class="modal-footer">
            <button type="submit" class="btn btn-success">Save</button>
            <button type="button" class="btn btn-secondary" @click="$emit('close')">Cancel</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, watch } from 'vue'
import axios from 'axios'
import { useUserStore } from '../../stores/user'

const props = defineProps<{ product: any | null }>()
const emit = defineEmits(['close', 'saved'])

const userStore = useUserStore()

const form = ref({
  name: '',
  description: '',
  category: '',
  price_rcoins: 0,
  stock: 0,
  image_url: ''
})

watch(() => props.product, (newProduct) => {
  if (newProduct) {
    form.value = { ...newProduct }
  } else {
    form.value = {
      name: '',
      description: '',
      category: '',
      price_rcoins: 0,
      stock: 0,
      image_url: ''
    }
  }
}, { immediate: true })

const submitForm = async () => {
  const headers = { Authorization: `Bearer ${userStore.token}` }

  if (props.product?.id) {
    await axios.patch(`/api/admin/products/${props.product.id}/`, form.value, { headers })
  } else {
    await axios.post('/api/admin/products/create/', form.value, { headers })
  }

  emit('saved')
}
</script>
