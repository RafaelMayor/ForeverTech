<template>
  <div class="modal-backdrop show fade" style="z-index: 1050;"></div>
  <div class="modal show d-block" tabindex="-1">
    <div class="modal-dialog">
      <div class="modal-content">
        <form @submit.prevent="submitForm">
          <div class="modal-header">
            <h5 class="modal-title">{{ offer?.id ? 'Edit' : 'Create' }} Offer</h5>
            <button type="button" class="btn-close" @click="$emit('close')"></button>
          </div>
          <div class="modal-body">
            <div class="mb-3">
              <label class="form-label">R-Coins</label>
              <input type="number" class="form-control" v-model.number="form.rcoins" required />
            </div>
            <div class="mb-3">
              <label class="form-label">Price (€)</label>
              <input type="number" step="0.01" class="form-control" v-model.number="form.price_eur" required />
            </div>
          </div>
          <div class="modal-footer">
            <button class="btn btn-success" type="submit">Save</button>
            <button class="btn btn-secondary" type="button" @click="$emit('close')">Cancel</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, watch } from 'vue'
import axios from 'axios'
import { useUserStore } from '../../stores/user'

const props = defineProps<{ offer: any | null }>()
const emit = defineEmits(['close', 'saved'])
const userStore = useUserStore()

const form = ref({
  rcoins: 0,
  price_eur: 0
})

watch(() => props.offer, (newOffer) => {
  if (newOffer) {
    form.value = {
      rcoins: newOffer.rcoins,
      price_eur: parseFloat(newOffer.price_eur)
    }
  } else {
    form.value = {
      rcoins: 0,
      price_eur: 0
    }
  }
}, { immediate: true })

const submitForm = async () => {
  const headers = { Authorization: `Bearer ${userStore.token}` }

  if (props.offer?.id) {
    await axios.patch(`/api/admin/rcoins-offers/${props.offer.id}/`, form.value, { headers })
  } else {
    await axios.post('/api/admin/rcoins-offers/', form.value, { headers })
  }

  emit('saved')
  emit('close')
}
</script>
