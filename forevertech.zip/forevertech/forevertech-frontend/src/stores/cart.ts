import { defineStore } from 'pinia'
import type { Product } from '../interfaces/Product'

export const useCartStore = defineStore('cart', {
  state: () => ({
    items: [] as { product: Product; quantity: number }[]
  }),
  getters: {
    total: (state) =>
      state.items.reduce((sum, item) => sum + item.product.price_rcoins * item.quantity, 0)
  },
  actions: {
    add(product: Product) {
      const item = this.items.find(i => i.product.id === product.id)
      if (item) {
        if (item.quantity < product.stock) item.quantity++
      } else {
        this.items.push({ product, quantity: 1 })
      }
    },
    remove(productId: number) {
      const index = this.items.findIndex(i => i.product.id === productId)
      if (index !== -1) this.items.splice(index, 1)
    },
    updateQuantity(productId: number, quantity: number) {
      const item = this.items.find(i => i.product.id === productId)
      if (item && quantity > 0 && quantity <= item.product.stock) {
        item.quantity = quantity
      }
    },
    clear() {
      this.items = []
    }
  },
  persist: true
})
