import { defineStore } from 'pinia'

export const useUserStore = defineStore('user', {
  state: () => ({
    uid: '',
    email: '',
    isAdmin: false,
    rcoins: 0,
  }),
  actions: {
    setUser(data: any) {
      this.uid = data.uid
      this.email = data.email
      this.isAdmin = data.is_admin
      this.rcoins = data.rcoins
    },
    clearUser() {
      this.uid = ''
      this.email = ''
      this.isAdmin = false
      this.rcoins = 0
    },
  },
  persist: true,
})
