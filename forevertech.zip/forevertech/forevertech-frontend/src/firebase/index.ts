import { initializeApp } from 'firebase/app'
import { getAuth } from 'firebase/auth'
import { getFirestore } from 'firebase/firestore'

const firebaseConfig = {
    apiKey: "AIzaSyCQg41LQt08tBRCtNVYuO1PaJbW-wI6Vd0",
    authDomain: "forevertech-31e46.firebaseapp.com",
    projectId: "forevertech-31e46",
    storageBucket: "forevertech-31e46.firebasestorage.app",
    messagingSenderId: "829614420476",
    appId: "1:829614420476:web:e9813b40d9b60c189fc279"
}

const app = initializeApp(firebaseConfig)

const auth = getAuth(app)
const db = getFirestore(app)

export { auth, db }
