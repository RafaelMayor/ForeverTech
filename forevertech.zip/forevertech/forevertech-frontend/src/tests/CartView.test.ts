import { mount } from '@vue/test-utils'
import { test, expect } from 'vitest'
import CartView from '../views/CartView.vue'
import { createTestingPinia } from '@pinia/testing'

test('renders cart and shows total', () => {
  const pinia = createTestingPinia({
    initialState: {
      cart: {
        items: [
          {
            product: {
              id: 1,
              name: 'Laptop',
              price_rcoins: 100,
              stock: 5,
              description: '',
              category: '',
              image_url: '',
              created_at: ''
            },
            quantity: 2
          }
        ]
      }
    }
  })

  const wrapper = mount(CartView, {
    global: {
      plugins: [pinia]
    }
  })

  expect(wrapper.text()).toContain('Laptop')
  expect(wrapper.text()).toContain('200 R-Coins')
})
