import { mount } from '@vue/test-utils'
import ProductsView from '../views/ProductsView.vue'
import { test, expect } from 'vitest'
import { createTestingPinia } from '@pinia/testing'

test('renders static content from ProductsView.vue', () => {
  const wrapper = mount(ProductsView, {
    global: {
      plugins: [createTestingPinia()],
      stubs: ['ProductCard'],
    }
  })

  expect(wrapper.text()).toContain('Filter by category:')
})
