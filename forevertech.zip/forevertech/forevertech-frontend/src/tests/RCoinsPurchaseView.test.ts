import { mount } from '@vue/test-utils'
import RCoinsPurchaseView from '../views/RCoinsPurchaseView.vue'
import { vi, test, expect } from 'vitest'
import { createTestingPinia } from '@pinia/testing'

vi.mock('../composables/useRCoinsOffers', () => ({
  useRCoinsOffers: () => ({
    offers: [{ id: 1, rcoins: 100, price_eur: 9.99 }]
  })
}))

test('renders R-Coins offers', () => {
  const wrapper = mount(RCoinsPurchaseView, {
    global: {
      plugins: [createTestingPinia()]
    }
  })

  expect(wrapper.text()).toContain('100 R-Coins')
  expect(wrapper.text()).toContain('9.99 €')
})
