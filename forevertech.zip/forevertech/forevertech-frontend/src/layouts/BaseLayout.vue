<template>
  <div class="d-flex flex-column min-vh-100">
    <Navbar />
    
    <main class="flex-fill">
      <router-view />
    </main>

    <footer class="bg-dark text-white text-center py-3 mt-auto">
      <div class="container">
        <small>© 2025 ForeverTech. All rights reserved.<br>Contact with us: rmarmay2004@gmail.com</small>
      </div>
    </footer>
  </div>
</template>

<script setup lang="ts">
import Navbar from '../components/Navbar.vue'
</script>

<style scoped>
main {
  padding-top: 1.5rem;
  padding-bottom: 1.5rem;
}
</style>
