export interface User {
    uid: string
    email: string
    is_admin: boolean
    rcoins: number
  }
  