import type { Product } from './Product'

export interface OrderItem {
	product: Product
	quantity: number
	price_at_purchase: number
}

export interface Order {
	id: number
	created_at: string
	total_rcoins: number
	items: OrderItem[]
}
