export interface RCoinsOffer {
    id: number
    rcoins: number
    price_eur: number
  }
  