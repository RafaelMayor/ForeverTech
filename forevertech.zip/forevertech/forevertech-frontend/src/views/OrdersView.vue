<template>
  <div class="container mt-5">
    <h2>Order History</h2>

    <div v-if="orders.length === 0">
      <p>No orders found.</p>
    </div>

    <div v-for="order in orders" :key="order.id" class="card mb-4">
      <div class="card-header">
        <strong>Order #{{ order.id }}</strong> - {{ formatDate(order.created_at) }}
      </div>
      <div class="card-body">
        <ul class="list-group">
          <li
            v-for="item in order.items"
            :key="item.product.id"
            class="list-group-item"
          >
            <div class="d-flex align-items-start gap-3">
              <img
                v-if="item.product.image_url"
                :src="item.product.image_url"
                alt="Product Image"
                class="img-thumbnail"
                style="width: 80px; height: 80px; object-fit: cover;"
              />
              <div class="flex-grow-1">
                <div class="fw-bold">{{ item.product.name }}</div>
                <small class="text-muted">{{ item.product.description }}</small>
                <div>
                  {{ item.quantity }} × {{ item.price_at_purchase }} R-Coins
                  = <strong>{{ item.quantity * item.price_at_purchase }} R-Coins</strong>
                </div>
              </div>
            </div>
          </li>
        </ul>
        <div class="text-end mt-3 fw-bold">Total: {{ order.total_rcoins }} R-Coins</div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import type { Order } from '../interfaces/Order'
import axios from 'axios'
import { getAuth } from 'firebase/auth'

const orders = ref<Order[]>([])

const fetchOrders = async () => {
  const user = getAuth().currentUser
  if (!user) return

  const idToken = await user.getIdToken()

  const res = await axios.get('/api/orders/', {
    headers: {
      Authorization: `Bearer ${idToken}`
    }
  })

  orders.value = res.data
}

const formatDate = (iso: string) => {
  const date = new Date(iso)
  return date.toLocaleString()
}

onMounted(fetchOrders)
</script>
