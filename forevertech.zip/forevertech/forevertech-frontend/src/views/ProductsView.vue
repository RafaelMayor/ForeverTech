<template>
  <div class="container mt-4">
    <h2>Products</h2>

    <div class="mb-3">
      <label>Filter by category:</label>
      <select v-model="selectedCategory" class="form-select w-auto">
        <option value="">All</option>
        <option v-for="cat in categories" :key="cat">{{ cat }}</option>
      </select>
    </div>

    <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3">
      <div
        v-for="product in filteredProducts"
        :key="product.id"
        class="col mb-4 d-flex"
      >
        <div class="card product-card w-100 shadow-sm d-flex flex-column transition-scale">
          <div class="product-img-wrapper">
            <img
              :src="product.image_url || 'https://via.placeholder.com/300x200?text=No+Image'"
              class="card-img-top"
              alt="Product image"
            />
          </div>
          <div class="card-body d-flex flex-column">
            <h5 class="card-title">{{ product.name }}</h5>
            <p class="card-text">{{ product.description }}</p>
            <p class="fw-bold text-primary">{{ product.price_rcoins }} R-Coins</p>
            <button
              class="btn btn-primary mt-auto"
              :disabled="product.stock === 0"
              @click="addToCart(product)"
            >
              {{ product.stock > 0 ? 'Add to Cart' : 'Out of Stock' }}
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue'
import { useProducts } from '../composables/useProducts'
import type { Product } from '../interfaces/Product'
import { useCartStore } from '../stores/cart'

const { products, categories } = useProducts()
const selectedCategory = ref('')

const cart = useCartStore()

const filteredProducts = computed(() =>
  selectedCategory.value
    ? products.value.filter(p => p.category === selectedCategory.value)
    : products.value
)

const addToCart = (product: Product) => {
  cart.add(product)
}
</script>

<style scoped>
.product-card {
  transition: transform 0.2s ease;
}

.product-card:hover {
  transform: scale(1.03);
  z-index: 2;
}

.product-img-wrapper {
  height: 200px;
  display: flex;
  justify-content: center;
  align-items: center;
  background-color: #f8f9fa;
  border-bottom: 1px solid #dee2e6;
}

.product-img-wrapper img {
  max-height: 100%;
  max-width: 100%;
  object-fit: contain;
}
</style>
