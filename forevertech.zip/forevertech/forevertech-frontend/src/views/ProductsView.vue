<template>
  <div class="container mt-4">
    <h2>Products</h2>

    <div class="mb-3">
      <label>Filter by category:</label>
      <select v-model="selectedCategory" class="form-select w-auto">
        <option value="">All</option>
        <option v-for="cat in categories" :key="cat">{{ cat }}</option>
      </select>
    </div>

    <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3">
      <div v-for="product in filteredProducts" :key="product.id" class="col-md-4 mb-4">
        <div class="card h-100">
          <img v-if="product.image_url" :src="product.image_url" class="card-img-top" />
          <div class="card-body">
            <h5 class="card-title">{{ product.name }}</h5>
            <p class="card-text">{{ product.description }}</p>
            <p class="fw-bold">{{ product.price_rcoins }} R-Coins</p>
            <button
              class="btn btn-primary"
              :disabled="product.stock === 0"
              @click="addToCart(product)"
            >
              {{ product.stock > 0 ? 'Add to Cart' : 'Out of Stock' }}
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue'
import { useProducts } from '../composables/useProducts'
import type { Product } from '../interfaces/Product'
import { useCartStore } from '../stores/cart'

const { products, categories } = useProducts()
const selectedCategory = ref('')

const cart = useCartStore()

const filteredProducts = computed(() =>
  selectedCategory.value
    ? products.value.filter(p => p.category === selectedCategory.value)
    : products.value
)

const addToCart = (product: Product) => {
  cart.add(product)
}
</script>
