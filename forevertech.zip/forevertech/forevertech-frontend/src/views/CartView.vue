<template>
  <div class="container mt-4">
    <h2>Your Cart</h2>

    <div v-if="items.length === 0">
      <p>Your cart is empty.</p>
    </div>

    <table v-else class="table">
      <thead>
        <tr>
          <th>Product</th>
          <th>Unit Price</th>
          <th>Quantity</th>
          <th>Subtotal</th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="item in items" :key="item.product.id">
          <td>{{ item.product.name }}</td>
          <td>{{ item.product.price_rcoins }} R-Coins</td>
          <td>
            <input type="number" class="form-control" min="1" :max="item.product.stock"
                   v-model.number="item.quantity"
                   @change="update(item.product.id, item.quantity)" />
          </td>
          <td>{{ item.product.price_rcoins * item.quantity }} R-Coins</td>
          <td>
            <button class="btn btn-danger btn-sm" @click="remove(item.product.id)">Remove</button>
          </td>
        </tr>
      </tbody>
    </table>

    <p class="fw-bold">Total: {{ total }} R-Coins</p>
    <button class="btn btn-success" @click="checkout" :disabled="items.length === 0">Checkout</button>
  </div>
</template>

<script setup lang="ts">
import { useCartStore } from '../stores/cart'
import { useUserStore } from '../stores/user'
import { computed } from 'vue'
import { refreshUserFromBackend } from '../utils/auth'
import axios from 'axios'

const cart = useCartStore()
const user = useUserStore()

const items = computed(() => cart.items)
const total = computed(() => cart.total)

const update = (productId: number, quantity: number) => {
  cart.updateQuantity(productId, quantity)
}

const remove = (productId: number) => {
  cart.remove(productId)
}

const checkout = async () => {
  try {
    const firebaseUser = (await import('firebase/auth')).getAuth().currentUser
    if (!firebaseUser) throw new Error('Not authenticated')

    const idToken = await firebaseUser.getIdToken()

    const order = {
      items: cart.items.map(item => ({
        product: item.product.id,
        quantity: item.quantity
      }))
    }

    await axios.post('/api/orders/', order, {
      headers: {
        Authorization: `Bearer ${idToken}`
      }
    })

    await refreshUserFromBackend()

    cart.clear()
    await user.fetchUserInfo()
    alert('Order placed successfully')
  } catch (err: any) {
    console.error('Checkout error:', err)
    alert(err.response?.data?.error || 'Error processing order')
  }
}
</script>
