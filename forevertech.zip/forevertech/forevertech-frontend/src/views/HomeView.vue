<template>
  <div class="container mt-5">
    <h1>Welcome to ForeverTech</h1>
    <p v-if="user.uid">You have {{ user.rcoins }} R-Coins.</p>
    <router-link to="/products" class="btn btn-success">View Products</router-link>
  </div>
</template>

<script setup lang="ts">
import { useUserStore } from '../stores/user'

const user = useUserStore()
</script>
