<template>
  <div class="container mt-5">
    <h1>Welcome to ForeverTech</h1>
    <p v-if="user.uid">You have {{ user.rcoins }} R-Coins.</p>
    <router-link to="/products" class="btn btn-success mb-4">View Products</router-link>

    <div v-if="loading" class="text-center">
      <div class="spinner-border" role="status" />
    </div>

    <div v-else-if="error" class="alert alert-danger">
      {{ error }}
    </div>

    <div v-else class="carousel-container">
      <h2 class="mb-3">Featured Products</h2>
      <div id="productCarousel" class="carousel slide" data-bs-ride="carousel">
        <div class="carousel-inner">
          <div
            class="carousel-item"
            v-for="(chunk, index) in productChunks"
            :class="{ active: index === 0 }"
            :key="index"
          >
            <div class="row justify-content-center">
              <div
                class="col-md-4 d-flex"
                v-for="product in chunk"
                :key="product.id"
              >
                <div class="card shadow-sm w-100 d-flex flex-column">
                  <div class="product-img-wrapper">
                    <img
                      :src="product.image_url || 'https://via.placeholder.com/300x200?text=No+Image'"
                      class="card-img-top"
                      alt="Product image"
                    />
                  </div>
                  <div class="card-body d-flex flex-column">
                    <h5 class="card-title">{{ product.name }}</h5>
                    <p class="card-text">{{ product.description }}</p>
                    <p class="card-text text-primary fw-bold">
                      {{ product.price_rcoins }} R-Coins
                    </p>
                    <router-link
                      :to="`/products`"
                      class="btn btn-outline-primary mt-auto"
                    >
                      View
                    </router-link>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <button
          class="carousel-control-prev"
          type="button"
          data-bs-target="#productCarousel"
          data-bs-slide="prev"
        >
          <span class="carousel-control-prev-icon" aria-hidden="true" />
          <span class="visually-hidden">Previous</span>
        </button>
        <button
          class="carousel-control-next"
          type="button"
          data-bs-target="#productCarousel"
          data-bs-slide="next"
        >
          <span class="carousel-control-next-icon" aria-hidden="true" />
          <span class="visually-hidden">Next</span>
        </button>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, computed } from 'vue'
import axios from 'axios'
import { useUserStore } from '../stores/user'

const user = useUserStore()
const products = ref<any[]>([])
const error = ref<string | null>(null)
const loading = ref(true)

const fetchProducts = async () => {
  try {
    const res = await axios.get('/api/products/')
    products.value = res.data
  } catch (err: any) {
    error.value = err.response?.data?.detail || 'Failed to load products'
  } finally {
    loading.value = false
  }
}

const productChunks = computed(() => {
  const chunks = []
  for (let i = 0; i < products.value.length; i += 3) {
    chunks.push(products.value.slice(i, i + 3))
  }
  return chunks
})

onMounted(fetchProducts)
</script>

<style scoped>
.carousel-container {
  margin-top: 2rem;
}

.product-img-wrapper {
  height: 200px;
  display: flex;
  justify-content: center;
  align-items: center;
  background-color: #f8f9fa;
  border-bottom: 1px solid #dee2e6;
}

.product-img-wrapper img {
  max-height: 100%;
  max-width: 100%;
  object-fit: contain;
}
</style>
