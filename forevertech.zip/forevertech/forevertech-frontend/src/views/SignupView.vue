<template>
  <div class="container mt-5">
    <h2>Signup</h2>
    <form @submit.prevent="signup">
      <div class="mb-3">
        <label>Email</label>
        <input v-model="email" type="email" class="form-control" required />
      </div>
      <div class="mb-3">
        <label>Password</label>
        <input v-model="password" type="password" class="form-control" required />
      </div>
      <button class="btn btn-success">Signup</button>
    </form>
    <div v-if="error" class="text-danger mt-3">{{ error }}</div>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import { createUserWithEmailAndPassword } from 'firebase/auth'
import { auth } from '../firebase'
import axios from 'axios'
import { useUserStore } from '../stores/user'
import { useRouter } from 'vue-router'

const email = ref('')
const password = ref('')
const error = ref('')
const userStore = useUserStore()
const router = useRouter()

const signup = async () => {
  error.value = ''
  try {
    const result = await createUserWithEmailAndPassword(auth, email.value, password.value)
    const token = await result.user.getIdToken()

    const response = await axios.post('/api/auth/', {
      idToken: token,
    })

    userStore.setUser(response.data)
    router.push('/')
  } catch (err: any) {
    console.error('Signup error:', err)
    error.value = err?.message || 'Signup failed. Try again.'
  }
}
</script>
