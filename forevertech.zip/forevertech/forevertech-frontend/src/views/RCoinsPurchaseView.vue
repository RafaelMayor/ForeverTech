<template>
  <div class="container mt-4">
    <h2>Buy R-Coins</h2>

    <div class="row">
      <div
        class="col-12 col-sm-6 col-md-4"
        v-for="offer in offers"
        :key="offer.id"
      >
        <div class="card mb-3">
          <div class="card-body text-center">
            <h5 class="card-title">{{ offer.rcoins }} R-Coins</h5>
            <p class="card-text text-muted">{{ Number(offer.price_eur).toFixed(2) }} €</p>
            <button class="btn btn-success" @click="buy(offer)">
              Buy
            </button>
          </div>
        </div>
      </div>
    </div>

    <div v-if="message" class="alert alert-success mt-4">{{ message }}</div>
  </div>
</template>

<script setup lang="ts">
import { useRCoinsOffers } from '../composables/useRCoinsOffers'
import type { RCoinsOffer } from '../interfaces/RCoinsOffer'
import { getAuth } from 'firebase/auth'
import axios from 'axios'
import { useUserStore } from '../stores/user'
import { ref } from 'vue'

const { offers } = useRCoinsOffers()
const userStore = useUserStore()
const message = ref('')

const buy = async (offer: RCoinsOffer) => {
  const user = getAuth().currentUser
  if (!user) return alert('You must be logged in.')

  const idToken = await user.getIdToken()

  // Simulated payment step (always succeeds for now)
  const confirmed = confirm(`Confirm simulated payment of ${Number(offer.price_eur).toFixed(2)} € for ${offer.rcoins} R-Coins?`)
  if (!confirmed) return

  const response = await axios.post(
    '/api/purchase-rcoins/',
    { offer_id: offer.id },
    {
      headers: { Authorization: `Bearer ${idToken}` }
    }
  )

  // Actualiza el usuario globalmente
  userStore.setUser(response.data)
  message.value = `Purchase successful! You now have ${response.data.rcoins} R-Coins.`
}
</script>
