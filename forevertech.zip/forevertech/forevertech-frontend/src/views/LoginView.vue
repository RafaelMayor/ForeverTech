<template>
  <div class="container mt-5">
    <h2>Login</h2>
    <form @submit.prevent="login">
      <div class="mb-3">
        <label>Email</label>
        <input v-model="email" type="email" class="form-control" required />
      </div>
      <div class="mb-3">
        <label>Password</label>
        <input v-model="password" type="password" class="form-control" required />
      </div>
      <button class="btn btn-primary">Login</button>
    </form>
    <div v-if="error" class="text-danger mt-3">{{ error }}</div>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import { signInWithEmailAndPassword } from 'firebase/auth'
import { auth } from '../firebase'
import axios from 'axios'
import { useUserStore } from '../stores/user'
import { useRouter } from 'vue-router'

const email = ref('')
const password = ref('')
const error = ref('')
const userStore = useUserStore()
const router = useRouter()

const login = async () => {
  error.value = ''
  try {
    const result = await signInWithEmailAndPassword(auth, email.value, password.value)
    const token = await result.user.getIdToken()

    const response = await axios.post('/api/auth/', {
      idToken: token,
    })

    userStore.setUser(response.data)
    router.push('/')
  } catch (err: any) {
    error.value = 'Login failed. Check credentials.'
  }
}
</script>
