<template>
  <div class="container py-4">
    <h2>🧾 Order History</h2>

    <div v-if="loading" class="text-center my-5">
      <div class="spinner-border" role="status" />
    </div>

    <div v-else-if="error" class="alert alert-danger">
      {{ error }}
    </div>

    <div v-else>
      <div v-if="orders.length === 0" class="alert alert-info">
        No orders found.
      </div>

      <div v-else class="table-responsive">
        <table class="table table-bordered table-hover align-middle">
          <thead class="table-dark">
            <tr>
              <th>ID</th>
              <th>User</th>
              <th>Products</th>
              <th>Total R-Coins</th>
              <th>Date</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="order in orders" :key="order.id">
              <td>{{ order.id }}</td>
              <td>{{ order.user?.email || 'N/A' }}</td>
              <td>
                <ul class="mb-0">
                  <li v-for="item in order.items" :key="item.product">
                    {{ item.product_name }} × {{ item.quantity }} ({{ item.price_at_purchase }} R-Coins)
                  </li>
                </ul>
              </td>
              <td>{{ order.total_rcoins }}</td>
              <td>{{ formatDate(order.created_at) }}</td>
              <td>
                <button class="btn btn-sm btn-danger" @click="revokeOrder(order.id)">
                  Revoke
                </button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useUserStore } from '../../stores/user'
import axios from 'axios'

const orders = ref<any[]>([])
const loading = ref(true)
const error = ref<string | null>(null)

const userStore = useUserStore()

const fetchOrders = async () => {
  loading.value = true
  try {
    const res = await axios.get('/api/admin/orders/', {
      headers: {
        Authorization: userStore.token,
      },
    })
    orders.value = res.data
  } catch (err: any) {
    error.value = err.response?.data?.detail || 'Failed to load orders'
  } finally {
    loading.value = false
  }
}

const revokeOrder = async (orderId: number) => {
  if (!confirm('Are you sure you want to revoke this order and refund R-Coins?')) return

  try {
    await axios.post(`/api/admin/orders/${orderId}/revoke/`, {}, {
      headers: {
        Authorization: userStore.token,
      },
    })
    alert('Order revoked and R-Coins refunded.')
    await fetchOrders()
  } catch (err: any) {
    alert(err.response?.data?.detail || 'Failed to revoke order.')
  }
}

const formatDate = (dateStr: string) => {
  return new Date(dateStr).toLocaleString()
}

onMounted(fetchOrders)
</script>
