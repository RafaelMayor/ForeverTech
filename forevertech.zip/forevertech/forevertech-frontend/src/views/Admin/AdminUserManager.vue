<template>
  <div class="container mt-4">
    <h2>User Management</h2>

    <table class="table table-bordered table-hover mt-3">
      <thead class="table-dark">
        <tr>
          <th>Email</th>
          <th>Is Admin</th>
          <th>R-Coins</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="user in users" :key="user.uid">
          <td>{{ user.email }}</td>
          <td>
            <span :class="user.is_admin ? 'text-success fw-bold' : 'text-muted'">
              {{ user.is_admin ? 'Yes' : 'No' }}
            </span>
          </td>
          <td>{{ user.rcoins }}</td>
          <td>
            <button class="btn btn-sm btn-primary" @click="editUser(user)">Edit</button>
          </td>
        </tr>
      </tbody>
    </table>

    <UserEditModal
      v-if="showModal"
      :user="selectedUser"
      @close="closeModal"
      @saved="fetchUsers"
    />
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import axios from 'axios'
import { useUserStore } from '../../stores/user'
import UserEditModal from '../../components/admin/UserEditModal.vue'

interface User {
  uid: string
  email: string
  is_admin: boolean
  rcoins: number
}

const users = ref<User[]>([])
const selectedUser = ref<User | null>(null)
const showModal = ref(false)
const userStore = useUserStore()

const fetchUsers = async () => {
  const res = await axios.get('/api/admin/users/', {
    headers: { Authorization: `Bearer ${userStore.token}` }
  })
  users.value = res.data
}

const editUser = (user: User) => {
  selectedUser.value = { ...user }
  showModal.value = true
}

const closeModal = () => {
  showModal.value = false
  selectedUser.value = null
}

onMounted(fetchUsers)
</script>
