<template>
  <div class="container mt-4">
    <h2>User Management</h2>

    <table class="table table-bordered table-hover mt-3">
      <thead class="table-dark">
        <tr>
          <th>Email</th>
          <th>Is Admin</th>
          <th>R-Coins</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="user in users" :key="user.uid">
          <td>{{ user.email }}</td>
          <td>
            <span :class="user.is_admin ? 'text-success fw-bold' : 'text-muted'">
              {{ user.is_admin ? 'Yes' : 'No' }}
            </span>
          </td>
          <td>{{ user.rcoins }}</td>
          <td>
            <button class="btn btn-sm btn-primary me-2" @click="editUser(user)">Edit</button>
            <button class="btn btn-sm btn-danger" @click="deleteUser(user)">Delete</button>
          </td>
        </tr>
      </tbody>
    </table>

    <UserEditModal
      v-if="showModal"
      :user="selectedUser"
      @close="closeModal"
      @saved="fetchUsers"
    />
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import axios from 'axios'
import { useUserStore } from '../../stores/user'
import UserEditModal from '../../components/admin/UserEditModal.vue'

interface User {
  uid: string
  email: string
  is_admin: boolean
  rcoins: number
}

const users = ref<User[]>([])
const selectedUser = ref<User | null>(null)
const showModal = ref(false)
const userStore = useUserStore()

const fetchUsers = async () => {
  const res = await axios.get('/api/admin/users/', {
    headers: { Authorization: `Bearer ${userStore.token}` }
  })
  users.value = res.data
}

const editUser = (user: User) => {
  selectedUser.value = { ...user }
  showModal.value = true
}

const deleteUser = async (user: User) => {
  if (!confirm(`Are you sure you want to delete ${user.email}?`)) return
  try {
    await axios.delete(`/api/admin/users/${user.uid}/delete/`, {
      headers: { Authorization: `Bearer ${userStore.token}` }
    })
    await fetchUsers()
  } catch (err) {
    alert('Error deleting user: ' + err.response?.data?.detail || err.message)
  }
}

const closeModal = () => {
  showModal.value = false
  selectedUser.value = null
}

onMounted(fetchUsers)
</script>
