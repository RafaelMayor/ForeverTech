<template>
  <div class="container mt-4">
    <h2>R-Coins Offer Management</h2>

    <button class="btn btn-success my-3" @click="openCreateForm">+ New Offer</button>

    <table class="table table-bordered table-striped">
      <thead class="table-dark">
        <tr>
          <th>ID</th>
          <th>R-Coins</th>
          <th>Price (€)</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="offer in offers" :key="offer.id">
          <td>{{ offer.id }}</td>
          <td>{{ offer.rcoins }}</td>
          <td>{{ offer.price_eur }} €</td>
          <td>
            <button class="btn btn-sm btn-primary me-2" @click="editOffer(offer)">Edit</button>
            <button class="btn btn-sm btn-danger" @click="deleteOffer(offer.id)">Delete</button>
          </td>
        </tr>
      </tbody>
    </table>

    <RCoinsOfferModal
      v-if="showModal"
      :offer="selectedOffer"
      @close="closeModal"
      @saved="fetchOffers"
    />
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import axios from 'axios'
import { useUserStore } from '../../stores/user'
import RCoinsOfferModal from '../../components/admin/RCoinsOfferModal.vue'

interface Offer {
  id: number
  rcoins: number
  price_eur: number
}

const offers = ref<Offer[]>([])
const selectedOffer = ref<Offer | null>(null)
const showModal = ref(false)

const userStore = useUserStore()

const fetchOffers = async () => {
  const res = await axios.get('/api/admin/rcoins-offers/', {
    headers: { Authorization: `Bearer ${userStore.token}` }
  })
  offers.value = res.data
}

const openCreateForm = () => {
  selectedOffer.value = null
  showModal.value = true
}

const editOffer = (offer: Offer) => {
  selectedOffer.value = { ...offer }
  showModal.value = true
}

const deleteOffer = async (id: number) => {
  if (!confirm('Are you sure you want to delete this offer?')) return
  await axios.delete(`/api/admin/rcoins-offers/${id}/delete/`, {
    headers: { Authorization: `Bearer ${userStore.token}` }
  })
  await fetchOffers()
}

const closeModal = () => {
  showModal.value = false
  selectedOffer.value = null
}

onMounted(fetchOffers)
</script>
