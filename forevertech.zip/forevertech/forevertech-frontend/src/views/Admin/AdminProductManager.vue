<template>
  <div class="container mt-4">
    <h2>Product Management</h2>

    <button class="btn btn-success my-3" @click="openCreateForm">+ New Product</button>

    <table v-if="products.length" class="table table-bordered table-striped">
      <thead class="table-dark">
        <tr>
          <th>Name</th>
          <th>Category</th>
          <th>Price (R-Coins)</th>
          <th>Stock</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="product in products" :key="product.id">
          <td>{{ product.name }}</td>
          <td>{{ product.category }}</td>
          <td>{{ product.price_rcoins }}</td>
          <td>{{ product.stock }}</td>
          <td>
            <button class="btn btn-sm btn-primary me-2" @click="editProduct(product)">Edit</button>
            <button class="btn btn-sm btn-danger" @click="deleteProduct(product.id)">Delete</button>
          </td>
        </tr>
      </tbody>
    </table>
    <div v-else class="alert alert-info">No products found.</div>

    <ProductFormModal
      v-if="showForm"
      :product="selectedProduct"
      @close="closeForm"
      @saved="handleSaved"
    />
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import axios from 'axios'
import { useUserStore } from '../../stores/user'
import ProductFormModal from '../../components/admin/ProductFormModal.vue'

const products = ref([])
const showForm = ref(false)
const selectedProduct = ref(null)
const userStore = useUserStore()

const fetchProducts = async () => {
  try {
    const res = await axios.get('/api/admin/products/', {
      headers: {
        Authorization: `Bearer ${userStore.token}`
      }
    })
    products.value = res.data
  } catch (err) {
    alert('Error loading products: ' + err.response?.data?.detail || err.message)
  }
}

const deleteProduct = async (id: number) => {
  if (!confirm('Are you sure?')) return
  try {
    await axios.delete(`/api/admin/products/${id}/delete/`, {
      headers: { Authorization: `Bearer ${userStore.token}` }
    })
    await fetchProducts()
  } catch (err) {
    alert('Error deleting product: ' + err.response?.data?.detail || err.message)
  }
}

const openCreateForm = () => {
  selectedProduct.value = null
  showForm.value = true
}

const editProduct = (product) => {
  selectedProduct.value = { ...product }
  showForm.value = true
}

const closeForm = () => {
  showForm.value = false
  selectedProduct.value = null
}

const handleSaved = async () => {
  await fetchProducts()
  closeForm()
}

onMounted(fetchProducts)
</script>
