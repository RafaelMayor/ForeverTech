import axios from 'axios'
import { getAuth } from 'firebase/auth'
import { useUserStore } from '../stores/user'

export async function refreshUserFromBackend() {
  const auth = getAuth()
  const user = auth.currentUser
  const userStore = useUserStore()

  if (!user) return

  const token = await user.getIdToken()
  const res = await axios.post('/api/auth/', { idToken: token })
  userStore.setUser(res.data)
}
