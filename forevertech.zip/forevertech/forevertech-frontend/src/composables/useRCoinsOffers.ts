import { ref, onMounted } from 'vue'
import axios from 'axios'
import type { RCoinsOffer } from '../interfaces/RCoinsOffer'

const offers = ref<RCoinsOffer[]>([])

const fetchOffers = async () => {
  const res = await axios.get<RCoinsOffer[]>('/api/rcoins-offers/')
  offers.value = res.data
}

export function useRCoinsOffers() {
  onMounted(fetchOffers)
  return { offers }
}
