import { ref, computed, onMounted } from 'vue'
import axios from 'axios'
import type { Product } from '../interfaces/Product'

const products = ref<Product[]>([])
const categories = computed(() => [...new Set(products.value.map(p => p.category))])

const fetchProducts = async () => {
  const res = await axios.get<Product[]>('/api/products/')
  products.value = res.data
}

export function useProducts() {
  onMounted(fetchProducts)
  return { products, categories }
}
