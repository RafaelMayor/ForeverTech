import { createRouter, createWebHistory } from 'vue-router'
import HomeView from '../views/HomeView.vue'
import LoginView from '../views/LoginView.vue'
import SignupView from '../views/SignupView.vue'
import ProductsView from '../views/ProductsView.vue'
import OrdersView from '../views/OrdersView.vue'
import RCoinsPurchaseView from '../views/RCoinsPurchaseView.vue'
import AdminProductManager from '../views/Admin/AdminProductManager.vue'
import AdminUserManager from '../views/Admin/AdminUserManager.vue'
import AdminRCoinsOffers from '../views/Admin/AdminRCoinsOffers.vue'
import AdminOrderHistory from '../views/Admin/AdminOrderHistory.vue'
import { useUserStore } from '../stores/user'

const routes = [
  { path: '/', name: 'Home', component: HomeView },
  { path: '/login', name: 'Login', component: LoginView },
  { path: '/signup', name: 'Signup', component: SignupView },
  { path: '/products', name: 'Products', component: ProductsView },
  { path: '/cart', name: 'Cart', component: () => import('../views/CartView.vue')},
  { path: '/orders', name: 'Orders', component: OrdersView },
  { path: '/buy-rcoins', name: 'BuyRCoins', component: RCoinsPurchaseView },
  { path: '/admin/products', component: AdminProductManager, meta: { requiresAdmin: true } },
  { path: '/admin/users', component: AdminUserManager, meta: { requiresAdmin: true } },
  { path: '/admin/rcoins-offers', component: AdminRCoinsOffers, meta: { requiresAdmin: true } },
  { path: '/admin/orders', component: AdminOrderHistory, meta: { requiresAdmin: true } },
]

const router = createRouter({
  history: createWebHistory(),
  routes,
})

// Middleware para proteger rutas admin
router.beforeEach((to, from, next) => {
  const userStore = useUserStore()
  if (to.meta.requiresAdmin && !userStore.isAdmin) {
    next({ path: '/' }) // redirige a home si no es admin
  } else {
    next()
  }
})

export default router
