<template>
  <BaseLayout />
</template>

<script setup lang="ts">
import BaseLayout from './layouts/BaseLayout.vue'
</script>
